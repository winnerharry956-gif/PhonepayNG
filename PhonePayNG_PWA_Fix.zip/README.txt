PWABuilder fix for PhonePay NG

Upload manifest.json to the same GitHub Pages root as index.html.
Then add this inside the <head> of index.html:
<link rel="manifest" href="manifest.json">
<meta name="theme-color" content="#00A898">

PHONEPAY NG ANDROID PROJECT

This is a buildable Android Studio project. It contains the working PhonePay NG calculator as an offline WebView app.

Test: phone price 163500, upfront 20000, 6 months -> balance 143500; monthly 23916.67; weekly approximately 5504.49.

To build an APK: open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s). The APK will be generated under app/build/outputs/apk/.

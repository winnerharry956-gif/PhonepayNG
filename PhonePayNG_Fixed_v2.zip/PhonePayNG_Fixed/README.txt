PhonePay NG - Fixed Calculator

This version accepts money entered as:
₦163,500
163,500
163500

Test:
Phone price: ₦163,500
Upfront: ₦20,000
Period: 6 months

Expected:
Remaining balance: ₦143,500.00
Monthly: ₦23,916.67
Weekly: ₦5,504.49

Open index.html in a browser. No database, account, internet connection, or payment is required.
